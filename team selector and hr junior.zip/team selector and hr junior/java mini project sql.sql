create schema java_demo;
use java_demo;

CREATE TABLE employeebot (
    EmpId INT ,
    EmpName varchar(20) ,
    StartingTime int ,
    EndTime int  ,
    desig varchar(20),
    status_ varchar(20))
    ;

insert into employeebot values(101,'anirudh',800,2200,'jr','free');
insert into employeebot values(102,'Ankush',900,1500,'se','free');
insert into employeebot values(103,'Meshank',1000,1200,'se','free');
insert into employeebot values(104,'suprith',830,1700,'se','free');
insert into employeebot values(105,'Shivabasava',0900,1800,'jr','working');
insert into employeebot values(106,'aditya',1000,2000,'se','working');
insert into employeebot values(107,'ashwin',0900,1100,'jr','working');
insert into employeebot values(108,'phanindra',1750,2200,'se','free');
insert into employeebot values(109,'charan',1300,2100,'jr','working');
insert into employeebot values(110,'bhuvan',1200,2300,'se','working');
insert into employeebot values(111,'jashwanth',1500,1700,'jr','free');
insert into employeebot values(112,'gagan',1400,1900,'jr','working');
insert into employeebot values(113,'shashank',1500,2400,'jr','free');
insert into employeebot values(114,'sujith',1000,2300,'jr','free');
insert into employeebot values(115,'harshith',0900,2100,'se','free');


-- SELECT 
--     EmpId,
--     COUNT(EmpId) AS number_of_employees,
--     SUM(TIME_TO_SEC(TIMEDIFF(LEAST(EndTime, '22:00:00'), GREATEST(StartingTime, '15:00:00')))) AS total_duration
-- FROM 
--     employeebot
-- WHERE 
--     StartingTime <= '22:00:00' AND EndTime >= '15:00:00'
-- GROUP BY 
--     EmpId
-- HAVING 
--     total_duration >= 2
-- ORDER BY 
--     number_of_employees ASC
-- LIMIT 5;

 select EmpId from employeebot where StartingTime<=2000 and EndTime>=1500 and desig='se' and status_='free';


-- SELECT
--     GROUP_CONCAT(EmpName ORDER BY EmpId) AS Employees,
--     SUM(TIMESTAMPDIFF(HOUR, GREATEST(Startingtime, '15:00:00'), LEAST(EndTime, '20:00:00'))) AS TotalWorkHours
-- FROM
--     employeebot
-- WHERE
--     Startingtime <= '20:00:00' AND EndTime >= '15:00:00'
-- GROUP BY
--     EmpId
-- HAVING
--     TotalWorkHours >= 20
-- ORDER BY
--     EmpId
-- limit 1
-- ;


-- select * from employeebot 
-- where StartTime>=


SELECT 
    GROUP_CONCAT(EmpName ORDER BY EmpId) AS EmployeeList,
    SUM(TIME_TO_SEC(TIMEDIFF(
        LEAST(EndTime, '20:00:00'),
        GREATEST(Startingtime, '15:00:00')
    )) / 3600) AS TotalWorkHours
FROM employeebot
WHERE Startingtime <= '20:00:00'
    AND EndTime >= '15:00:00'
GROUP BY EmpId
HAVING TotalWorkHours >= 20;

