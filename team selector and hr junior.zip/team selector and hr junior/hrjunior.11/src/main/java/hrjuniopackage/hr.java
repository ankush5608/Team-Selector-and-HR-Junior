package hrjuniopackage;
import java.util.Scanner;
import java.sql.*;
public class hr {
	
	public static void input_insert()
	{
		Scanner sc = new Scanner(System.in);
		String role_3;
		int start_time;
		int end_time;
		int E_id;
		String E_name;
		String status_2;
		
		System.out.println("Enter Employee id:");
		E_id=sc.nextInt();
		System.out.println("Enter Empoyee name:");
		E_name = sc.next();
		System.out.println("Enter Employee start time:");
		start_time = sc.nextInt();
		System.out.println("Enter Employee end time:");
		end_time = sc.nextInt();
		System.out.println("Specify the role of employee: ");
		role_3 = sc.next();
		System.out.println("Specify the status of employee(i.e working or free)");
		status_2 = sc.next();
		insert(E_id,E_name,start_time,end_time,role_3,status_2);
	}

	public static void insert(int eid, String ename, int strt_time, int end_time, String role_2, String status  )
	{
	
		String url = "jdbc:mysql://localhost:3306/java_demo";
        String username = "root";
        String password = "aiml123";

		        try {
		            Connection connection = DriverManager.getConnection(url, username, password);

		            String insertSql = "INSERT INTO employeebot (EmpId, EmpName, StartingTime, EndTime, desig, status_ ) VALUES (?, ?, ?, ?, ?, ?)";

		            PreparedStatement preparedStatement = connection.prepareStatement(insertSql);
		            preparedStatement.setInt(1, eid);
		            preparedStatement.setString(2, ename);
		            preparedStatement.setInt(3, strt_time);
		            preparedStatement.setInt(4, end_time);
		            preparedStatement.setString(5,role_2 );
		            preparedStatement.setString(6, status);

		            int rowsAffected = preparedStatement.executeUpdate();
		            System.out.println("Rows affected: " + rowsAffected);

		            preparedStatement.close();
		            connection.close();
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
		    
		

	}
	
	
	public static void input()
	{
		
		Scanner sc = new Scanner(System.in);
		String role;
		int work_duration_start_time;
		int work_duration_end_time;
		System.out.println("Enter the time in military format (eg:1700 for 17:00:00)");
		System.out.println("Provide us with the desired start time for your work:");
		work_duration_start_time = sc.nextInt();
		System.out.println("Kindly inform us of the preferred end time for your work:");
		work_duration_end_time = sc.nextInt();
		System.out.println("Please specify the role which you would need to do the work: ");
		role = sc.next();
		output(work_duration_start_time,work_duration_end_time,role);
		
	}
	public static void showdb()
	{
		String url = "jdbc:mysql://localhost:3306/java_demo";
        String username = "root";
        String password = "aiml123";

       
        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connected to the database!");
            
            
            Statement statement = connection.createStatement();

            
            String query = "SELECT * FROM employeebot";
            ResultSet resultSet = statement.executeQuery(query);

            
            while (resultSet.next()) {
//            	System.out.println("rvfvfv");
                int id = resultSet.getInt("EmpId");
                String name = resultSet.getString("EmpName");
                int start_time = resultSet.getInt("StartingTime");
                int end_time = resultSet.getInt("EndTime");
                String desig = resultSet.getString("desig");

                System.out.println("ID: " + id + ", Name: " + name +", Start Time: "+start_time+", End Time: "+end_time+", Designation: "+desig);
            }

            resultSet.close(); 
            statement.close(); 

            
            
            
            
            
            connection.close(); 
            System.out.println("Connection closed.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}
	public static void output(int start_time1, int end_time1 , String role_)
	{
		
		String url = "jdbc:mysql://localhost:3306/java_demo";
        String username = "root";
        String password = "aiml123";

       
        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connected to the database!");
            
            
            Statement statement = connection.createStatement();

            
            String query = "SELECT * FROM employeebot WHERE StartingTime <= ? AND EndTime >= ? AND desig = ? AND status_='free'";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, start_time1); 
            preparedStatement.setInt(2, end_time1); 
            preparedStatement.setString(3, role_); 
            ResultSet resultSet = preparedStatement.executeQuery();

            
//            ResultSet resultSet = statement.executeQuery(query);

            
            while (resultSet.next()) {
            	int id = resultSet.getInt("EmpId");
                String name = resultSet.getString("EmpName");
                int start_time = resultSet.getInt("StartingTime");
                int end_time = resultSet.getInt("EndTime");
                String desig = resultSet.getString("desig");
                

                System.out.println("ID: " + id + ", Name: " + name +", Start Time: "+start_time+", End Time: "+end_time+", Designation: "+desig);
            }

            resultSet.close(); 
            statement.close(); 

            
            
            
            
            
            connection.close(); 
            System.out.println("Connection closed.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}
	
	public static void main(String args[])
	{
//		String url = "jdbc:mysql://localhost:3306/java_demo";
//        String username = "root";
//        String password = "aiml123";
//
//       
//        try {
//            Connection connection = DriverManager.getConnection(url, username, password);
//            System.out.println("Connected to the database!");
//            
//            
//            Statement statement = connection.createStatement();
//
//            
//            String query = "SELECT * FROM data_demo WHERE desig = 'hr'";
//            ResultSet resultSet = statement.executeQuery(query);
//
//            
//            while (resultSet.next()) {
//                int id = resultSet.getInt("id");
//                String name = resultSet.getString("name_");
//                
//
//                System.out.println("ID: " + id + ", Name: " + name);
//            }
//
//            resultSet.close(); 
//            statement.close(); 
//
//            
//            
//            
//            
//            
//            connection.close(); 
//            System.out.println("Connection closed.");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
		String role="jr";
		hr hr_junior = new hr();
		hr_junior.showdb();
		hr_junior.input();
		hr_junior.input_insert();
	}
	
}
